import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

class Stud {

    private int s_rollno;
    private String s_name;
    private int age;

    Stud(int s_rollno, String s_name, int age) {
        this.s_rollno = s_rollno;
        this.s_name = s_name;
        this.age = age;
    }

    // get value of roll no , name , age of student
    public int getrollno() {
        return s_rollno;
    }

    public String getname() {
        return s_name;
    }

    public int getage() {
        return age;
    }

    public String toString() {
        return s_rollno + " " + s_name + " " + age;
    }

}

public class stud1 {
    public static void main(String[] args) {

        List<Stud> c = new ArrayList<Stud>();

        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Enter choice : ");
        int ch;
        do {
            System.out.println("1.INSERT ");
            System.out.println("2.DISPLAY");
            System.out.println("3.SEARCH");
            System.out.println("4.DELETE");
            System.out.println("5.UPDATE");

            ch = sc.nextInt();
            switch (ch) {
                case 1:
                    System.out.println("Enter Student Roll_no :");
                    int s_rollno = sc.nextInt();
                    System.out.println("Enter Student Name :");
                    String s_name = sc1.nextLine();
                    System.out.println("Enter Student age :");
                    int age = sc.nextInt();
                    // store in collectio
                    c.add(new Stud(s_rollno, s_name, age));
                    break;

                case 2:
                    // retrive one -by one data by iterater
                    System.out.println("--------------------------");
                    Iterator<Stud> i = c.iterator();
                    while (i.hasNext()) {
                        Stud s = i.next();
                        System.out.println(s);
                    }
                    System.out.println("--------------------------");
                    break;
                case 3:
                    boolean found = false;
                    System.out.println("Enter roll_no for search :");
                    int roll_no = sc.nextInt();
                    System.out.println("--------------------------");
                    i = c.iterator();
                    while (i.hasNext()) {
                        Stud s = i.next();
                        if (s.getrollno() == roll_no) {
                            System.out.println(s);
                            found = true;
                        }

                    }
                    if (!found) {
                        System.out.println("Record not found");
                    }
                    System.out.println("--------------------------");
                    break;

                case 4:
                    found = false;
                    System.out.println("Enter roll_no for Delete :");
                    roll_no = sc.nextInt();
                    System.out.println("--------------------------");
                    i = c.iterator();
                    while (i.hasNext()) {
                        Stud s = i.next();
                        if (s.getrollno() == roll_no) {
                            i.remove();
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    } else {
                        System.out.println("Record is deleted succesfully ..");
                    }
                    System.out.println("--------------------------");
                    break;

                case 5:
                    found = false;
                    System.out.println("Enter roll_no for Update :");
                    roll_no = sc.nextInt();
                    System.out.println("--------------------------");
                    ListIterator<Stud> s1 = c.listIterator();
                    while (s1.hasNext()) {
                        Stud s = s1.next();
                        if (s.getrollno() == roll_no) {
                            System.out.println("Enter new name : ");
                            s_name = sc.nextLine();

                            System.out.println("Enter new age : ");
                            age = sc.nextInt();
                            s1.set(new Stud(roll_no, s_name, age));
                            found = true;
                        }

                    }
                    if (!found) {
                        System.out.println("Record not found");
                    }else {
                        System.out.println("Record is Updated succesfully ..");
                    }
                    System.out.println("--------------------------");
                    break;
            }
        } while (ch != 0);
    }
}
